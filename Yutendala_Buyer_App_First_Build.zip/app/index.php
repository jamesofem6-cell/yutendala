<?php
/**
 * Yutendala Buyer App - first implementation
 * Install as /public_html/app/index.php. Uses the existing marketplace database
 * and links into the existing shop/checkout/payment flow; it does not create
 * duplicate buyer, product, order, or payment tables.
 */
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params(['lifetime'=>0, 'path'=>'/', 'secure'=>$https, 'httponly'=>true, 'samesite'=>'Lax']);
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/business_types.php';
require_once dirname(__DIR__) . '/pay-lib.php';
require_once dirname(__DIR__) . '/discover-stores.php';

function app_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function app_money($v): string { return '₦' . number_format((float)$v, 2); }
function app_img($file): string {
    $file = basename(trim((string)$file));
    return $file !== '' ? '/uploads/' . rawurlencode($file) : '';
}
function app_product_price(mysqli $db, string $slug, float $price): float {
    // Match the marketplace's existing buyer-facing price calculation where a
    // shop-specific pricing class is configured. Storefront checkout remains authoritative.
    $class = 'standard'; $pass = true;
    $st = $db->prepare('SELECT business_type FROM shop_settings WHERE shop_slug=? LIMIT 1');
    if ($st) {
        $st->bind_param('s', $slug); $st->execute();
        $r = $st->get_result()->fetch_assoc(); $st->close();
        if ($r && !empty($r['business_type'])) {
            $v = strtolower(trim((string)$r['business_type']));
            if (in_array($v, ['wellness','adult_wellness','adult-wellness'], true)) $class = 'wellness';
            elseif (in_array($v, ['massage','massage_wellness'], true)) $class = 'massage';
            elseif (in_array($v, ['tools','tool_hire'], true)) $class = 'tools';
        }
    }
    return function_exists('pay_markup') ? (float)pay_markup($price, $class, $pass) : round($price * 1.035, 2);
}

$db = $conn ?? null;
if (!$db instanceof mysqli) {
    http_response_code(503);
    exit('Yutendala is temporarily unavailable. Please try again shortly.');
}

$q = trim((string)($_GET['q'] ?? ''));
$category = trim((string)($_GET['category'] ?? ''));
$storesData = yt_list_stores($db, $q, $category, 12, 0);
$storeRows = $storesData['rows'];
$categories = $storesData['cats'];

// Product discovery is drawn from existing products and existing public shops.
// No vendor records are copied, re-created, or migrated by this page.
$products = [];
$searchLike = '%' . addcslashes($q, '%_\\') . '%';
$sql = "SELECT p.id, COALESCE(NULLIF(p.product_name,''), p.name) AS title,
               p.price, p.image1, p.description, p.detail, p.shop_slug,
               s.shop_name, s.category AS shop_category
        FROM products p
        INNER JOIN shops s ON s.shop_slug=p.shop_slug
        WHERE p.price > 0
          AND (s.is_active IS NULL OR s.is_active <> 0)
          AND (s.status IS NULL OR LOWER(TRIM(s.status)) NOT IN ('inactive','deleted','disabled','frozen','suspended','0'))
          AND (s.category IS NULL OR LOWER(TRIM(s.category)) NOT IN ('adult','adult_wellness','adult-wellness'))
          AND (s.shop_name IS NOT NULL AND s.shop_name <> '')";
$types = ''; $params = [];
if ($q !== '') {
    $sql .= " AND (COALESCE(NULLIF(p.product_name,''),p.name) LIKE ? OR p.description LIKE ? OR s.shop_name LIKE ?)";
    $types = 'sss'; $params = [$searchLike, $searchLike, $searchLike];
}
if ($category !== '') {
    $sql .= ' AND s.category = ?'; $types .= 's'; $params[] = $category;
}
$sql .= ' ORDER BY p.special DESC, p.id DESC LIMIT 12';
try {
    $st = $db->prepare($sql);
    if ($st) {
        if ($types !== '') $st->bind_param($types, ...$params);
        $st->execute(); $rs = $st->get_result();
        while ($rs && ($row = $rs->fetch_assoc())) $products[] = $row;
        $st->close();
    }
} catch (Throwable $e) { error_log('[Yutendala Buyer App] product discovery: ' . $e->getMessage()); }

?>
<!doctype html>
<html lang="en-NG">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#174d2a"><meta name="description" content="Shop products and discover trusted businesses on Yutendala.">
<link rel="manifest" href="/manifest.json"><link rel="apple-touch-icon" href="/pwa-192.png">
<title>Yutendala | Shop and discover</title>
<style>
:root{--green:#174d2a;--green2:#23733e;--lime:#e9f5e9;--ink:#17231a;--muted:#66736a;--line:#e6ece7;--paper:#f7f9f7;--white:#fff;--orange:#f29a38;--shadow:0 8px 24px rgba(21,52,30,.07)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;padding-bottom:82px}a{color:inherit;text-decoration:none}button,input{font:inherit}.wrap{width:min(1120px,100% - 28px);margin:auto}.top{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.96);backdrop-filter:blur(12px);border-bottom:1px solid var(--line)}.topin{height:64px;display:flex;align-items:center;gap:12px}.logo{display:flex;align-items:center;gap:8px;font-size:20px;font-weight:850;color:var(--green);letter-spacing:-.6px}.mark{width:34px;height:34px;border-radius:11px;background:var(--green);color:#fff;display:grid;place-items:center;font-size:19px}.topright{margin-left:auto;display:flex;align-items:center;gap:8px}.iconbtn{border:1px solid var(--line);background:#fff;border-radius:12px;padding:9px 12px;font-weight:700;font-size:13px}.hero{margin:18px auto 16px;background:linear-gradient(115deg,#123e24,#216b39 65%,#2f854b);color:#fff;border-radius:23px;padding:24px 22px;position:relative;overflow:hidden;min-height:208px}.hero:after{content:"";position:absolute;width:230px;height:230px;border:1px solid rgba(255,255,255,.14);border-radius:50%;right:-65px;top:-80px;box-shadow:0 0 0 28px rgba(255,255,255,.04),0 0 0 58px rgba(255,255,255,.035)}.eyebrow{font-size:11px;letter-spacing:1.6px;text-transform:uppercase;color:#d6f1d9;font-weight:800}.hero h1{font-size:clamp(27px,6vw,43px);line-height:1.08;letter-spacing:-1.4px;margin:10px 0 8px;max-width:600px}.hero p{margin:0;color:#e1f0e3;font-size:14px;max-width:430px}.search{display:flex;gap:8px;background:#fff;padding:7px;border-radius:14px;margin-top:19px;max-width:620px;position:relative;z-index:2;box-shadow:0 8px 22px rgba(0,0,0,.12)}.search input{min-width:0;flex:1;border:0;outline:0;padding:9px 10px;color:var(--ink)}.search button{border:0;background:var(--green);color:#fff;font-weight:800;padding:0 17px;border-radius:10px}.section{margin:24px auto}.secthead{display:flex;align-items:end;justify-content:space-between;gap:12px;margin-bottom:12px}.secthead h2{font-size:19px;letter-spacing:-.4px;margin:0}.secthead p{margin:3px 0 0;color:var(--muted);font-size:12px}.see{color:var(--green);font-size:13px;font-weight:800;white-space:nowrap}.quickcats{display:grid;grid-template-columns:repeat(4,1fr);gap:9px}.quick{background:#fff;border:1px solid var(--line);border-radius:15px;padding:13px 8px;text-align:center;min-height:94px;box-shadow:0 3px 12px rgba(20,45,25,.025)}.quick .emoji{font-size:25px;display:block;margin-bottom:5px}.quick b{font-size:11px;display:block}.filters{display:flex;gap:7px;overflow:auto;padding:2px 0 8px;scrollbar-width:none}.filters::-webkit-scrollbar{display:none}.chip{border:1px solid var(--line);border-radius:30px;background:#fff;padding:8px 13px;font-size:12px;font-weight:750;white-space:nowrap}.chip.active{background:var(--green);color:#fff;border-color:var(--green)}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}.product{background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;box-shadow:0 4px 15px rgba(22,49,28,.035)}.productimg{height:135px;background:#edf3ed;display:grid;place-items:center;overflow:hidden}.productimg img{width:100%;height:100%;object-fit:cover}.placeholder{font-size:38px;color:#8ca38e}.pbody{padding:10px}.pname{font-size:13px;font-weight:800;line-height:1.35;min-height:35px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.pstore{font-size:11px;color:var(--muted);margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pprice{font-size:13px;font-weight:850;color:var(--green);margin-top:7px}.visit{display:block;text-align:center;background:var(--lime);color:var(--green);font-size:11px;font-weight:850;border-radius:9px;padding:8px;margin-top:9px}.storegrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.store{background:#fff;border:1px solid var(--line);border-radius:15px;padding:12px;display:flex;gap:10px;min-width:0}.storelogo{width:48px;height:48px;border-radius:13px;flex:none;object-fit:cover;background:#e9f4e9}.storeinitial{display:grid;place-items:center;font-size:19px;font-weight:900;color:var(--green)}.storeinfo{min-width:0}.storeinfo b{font-size:12px;display:block;overflow-wrap:anywhere}.storeinfo small{font-size:10px;color:var(--muted);display:block;margin-top:4px}.storeinfo span{font-size:10px;color:var(--green);font-weight:800;display:block;margin-top:7px}.empty{background:#fff;border:1px dashed #cad7cc;border-radius:15px;padding:22px;text-align:center;color:var(--muted);font-size:13px;grid-column:1/-1}.servicebanner{background:#fff;border:1px solid var(--line);border-radius:17px;padding:16px;display:flex;align-items:center;gap:14px}.servicebanner .sicon{width:46px;height:46px;border-radius:14px;background:#fff2df;display:grid;place-items:center;font-size:24px}.servicebanner b{font-size:14px}.servicebanner p{margin:4px 0 0;color:var(--muted);font-size:11px}.servicebanner a{margin-left:auto;background:var(--green);color:#fff;border-radius:10px;padding:10px 12px;font-size:11px;font-weight:800;white-space:nowrap}.bottom{position:fixed;bottom:0;left:0;right:0;z-index:30;background:rgba(255,255,255,.97);border-top:1px solid var(--line);padding:8px 8px calc(8px + env(safe-area-inset-bottom));display:grid;grid-template-columns:repeat(4,1fr);backdrop-filter:blur(12px)}.bottom a{text-align:center;color:#758078;font-size:10px;font-weight:700;padding:3px}.bottom a strong{display:block;font-size:19px;line-height:24px;font-weight:500}.bottom a.on{color:var(--green)}footer{text-align:center;color:#8a958c;font-size:11px;padding:25px 10px 10px}
@media(min-width:700px){.hero{padding:34px 36px;min-height:250px}.quickcats{grid-template-columns:repeat(8,1fr)}.grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.productimg{height:175px}.storegrid{grid-template-columns:repeat(3,minmax(0,1fr))}.wrap{width:min(1120px,100% - 48px)}}
@media(max-width:390px){.wrap{width:calc(100% - 20px)}.topin{height:58px}.logo{font-size:18px}.iconbtn{padding:8px 9px}.hero{padding:20px 16px}.quickcats{gap:7px}.quick{padding:10px 4px}.store{padding:9px}.storelogo{width:42px;height:42px}}
</style>
</head>
<body>
<header class="top"><div class="wrap topin"><a class="logo" href="/app/"><span class="mark">Y</span> yutendala</a><div class="topright"><a class="iconbtn" href="/shops.php">Businesses</a><a class="iconbtn" href="https://wa.me/2349069695366">Help</a></div></div></header>
<main class="wrap">
<section class="hero"><div class="eyebrow">Your marketplace, all in one place</div><h1>Find what you need.<br>Love how easy it feels.</h1><p>Discover products, local businesses and helpful services on Yutendala.</p><form class="search" action="/app/" method="get"><input type="search" name="q" value="<?= app_h($q) ?>" placeholder="Search products, stores and services…" aria-label="Search marketplace"><button type="submit">Search</button></form></section>
<section class="section"><div class="secthead"><div><h2>Explore categories</h2><p>Start with what you are looking for</p></div></div><div class="quickcats">
<a class="quick" href="/app/?category=Food"><span class="emoji">🥬</span><b>Food & groceries</b></a>
<a class="quick" href="/app/?category=Fashion"><span class="emoji">👗</span><b>Fashion</b></a>
<a class="quick" href="/app/?category=Electronics"><span class="emoji">📱</span><b>Electronics</b></a>
<a class="quick" href="/app/?category=Beauty"><span class="emoji">✨</span><b>Beauty</b></a>
<a class="quick" href="/farm.php"><span class="emoji">🌴</span><b>Farm produce</b></a>
<a class="quick" href="/laundry.php"><span class="emoji">🧺</span><b>Laundry</b></a>
<a class="quick" href="/errands.php"><span class="emoji">🛵</span><b>Errands</b></a>
<a class="quick" href="/services.php"><span class="emoji">🧰</span><b>All services</b></a>
</div></section>
<section class="section"><div class="secthead"><div><h2><?= $q !== '' ? 'Search results' : 'Popular picks' ?></h2><p>Products from businesses on Yutendala</p></div><a class="see" href="/shops.php">Browse all →</a></div>
<div class="grid">
<?php if (!$products): ?><div class="empty">No matching products to show yet. Browse our businesses to discover more.</div><?php endif; ?>
<?php foreach ($products as $p): $title = trim((string)$p['title']); $img = app_img($p['image1']); $price = app_product_price($db, (string)$p['shop_slug'], (float)$p['price']); ?>
<a class="product" href="/shop.php?slug=<?= rawurlencode((string)$p['shop_slug']) ?>">
<div class="productimg"><?php if ($img !== ''): ?><img loading="lazy" src="<?= app_h($img) ?>" alt="<?= app_h($title) ?>" onerror="this.style.display='none';this.parentNode.innerHTML='<span class=&quot;placeholder&quot;>🛍️</span>'"><?php else: ?><span class="placeholder">🛍️</span><?php endif; ?></div>
<div class="pbody"><div class="pname"><?= app_h($title !== '' ? $title : 'Marketplace item') ?></div><div class="pstore"><?= app_h($p['shop_name']) ?></div><div class="pprice"><?= app_money($price) ?></div><span class="visit">View item & store →</span></div></a>
<?php endforeach; ?>
</div></section>
<section class="section"><div class="secthead"><div><h2>Discover businesses</h2><p>Explore shops without having to search first</p></div><a class="see" href="/shops.php">See all →</a></div>
<?php if ($categories): ?><div class="filters"><a class="chip <?= $category === '' ? 'active' : '' ?>" href="/app/">All businesses</a><?php foreach ($categories as $c): ?><a class="chip <?= $category === $c ? 'active' : '' ?>" href="/app/?category=<?= rawurlencode($c) ?>"><?= app_h($c) ?></a><?php endforeach; ?></div><?php endif; ?>
<div class="storegrid">
<?php if (!$storeRows): ?><div class="empty">No businesses matched this selection. Try another category.</div><?php endif; ?>
<?php foreach ($storeRows as $s): $logo = app_img($s['logo'] ?? ''); $sn = trim((string)$s['name']); ?>
<a class="store" href="<?= app_h(yt_store_url($s['slug'])) ?>"><?php if ($logo): ?><img class="storelogo" src="<?= app_h($logo) ?>" alt="" loading="lazy"><?php else: ?><span class="storelogo storeinitial"><?= app_h(strtoupper(substr($sn,0,1))) ?></span><?php endif; ?><span class="storeinfo"><b><?= app_h($sn) ?></b><small><?= app_h($s['category'] ?: 'Business') ?><?= !empty($s['city']) ? ' · '.app_h($s['city']) : '' ?></small><span>Visit business →</span></span></a>
<?php endforeach; ?>
</div></section>
<section class="section"><div class="servicebanner"><span class="sicon">🚚</span><div><b>Need something delivered?</b><p>Choose delivery during checkout where the business supports it.</p></div><a href="/delivery-shop.php">Delivery info</a></div></section>
<footer>Yutendala · Bringing you happiness through service.<br>© <?= date('Y') ?> Yutendalafarms Ltd</footer>
</main>
<nav class="bottom" aria-label="Main navigation"><a class="on" href="/app/"><strong>⌂</strong>Home</a><a href="/shops.php"><strong>▦</strong>Discover</a><a href="/services.php"><strong>◇</strong>Services</a><a href="https://wa.me/2349069695366"><strong>☏</strong>Help</a></nav>
<script>if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}</script>
</body></html>
