YUTENDALA BUYER APP — FIRST BUILD

WHAT THIS ADDS
- A mobile-first buyer marketplace home at /app/
- Product discovery from the existing products table
- Business discovery from the existing shops/shop_settings tables
- Search and category filters
- Links into the existing shop storefront, cart, checkout and Paystack payment flow
- Links to existing buyer sign-in/account pages and service pages

INSTALLATION
1. Make a backup of the current public_html folder before changing anything.
2. In cPanel File Manager, open public_html.
3. Create a folder named app.
4. Upload index.php from this package into public_html/app/.
5. Do NOT upload or replace config.php, database credentials, Paystack keys, or any existing marketplace files.
6. Open https://yutendala.ng/app/ in Chrome.

REQUIREMENTS / DEPENDENCIES
This first build reuses existing files already present in public_html:
- config.php
- business_types.php
- pay-lib.php
- discover-stores.php
- /uploads/ product and shop images
- existing database tables: products, shops, shop_settings
- existing routes: shop.php, shops.php, buyer-login.php, buyer-account.php, services.php, laundry.php, farm.php, errands.php

IMPORTANT
- This is the buyer-facing first screen, not the completed app.
- Checkout and payment remain on the existing shop.php -> shop-order.php -> pay-start.php flow.
- No database migration or new tables are required.
- Existing vendor/admin/logistics interfaces are not replaced or modified by this package.
- Before production launch, test on the live database, check all displayed price classes against the storefront, and verify the buyer session key used by buyer-account.php. This page intentionally does not create or alter login sessions.
- The app reads active public shops and excludes adult-restricted categories from general discovery.

NEXT BUILD STAGES
1. Buyer app: category/search refinements, product detail, cart continuity, buyer sign-in integration, order history and order tracking.
2. Vendor app: mobile dashboard, products/variants, inventory, orders and earnings.
3. Admin app: marketplace overview, vendor/business approvals, orders, commissions, payments, delivery and audit controls.
